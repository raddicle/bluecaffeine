<?php
/**
  * Get an api_key and secret from facebook and fill in this content.
  * save the file to app/Config/facebook.php
  */
  $config = array(
  	'Facebook' => array(
  		'appId' => '207436486000563',
  		'apiKey' => '207436486000563',
  		'secret' => '78c6d3c40c10280180f71dd3c68cbda1',
  		'cookie' => true,
  		'locale' => 'en_US',
  		)
  	);
?>
